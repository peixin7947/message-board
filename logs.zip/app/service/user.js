'use strict';
const Service = require('egg').Service;

class UserService extends Service {
  async findUser() {
    const result = await this.ctx.model.User.find();
    return result;
  }

  async addUser(user) {
    const userObj = new this.ctx.model.User({
      username: user.username,
      password: user.password,
    });
    userObj.save();
  }

  async updateUser(user) {
    const result = await this.ctx.model.User.updateOne(user);
    return result;
  }

  async deleteUser(user) {
    const result = await this.ctx.model.User.deleteOne(user);
    return result;
  }
}

module.exports = UserService;
