'use strict';
const Joi = require('joi');
const Controller = require('egg').Controller;

class AuthController extends Controller {
  async login() {
    return;
  }

  async register() {
    const { ctx } = this;
    const user = ctx.request.body;
    if (!user.password || !user.repassword) {
      await ctx.render('/home/register.tpl', { message: '密码不能为空' });
      return;
    } else if (user.password !== user.repassword) {
      await ctx.render('/home/register.tpl', { message: '2次输入的密码不一致' });
      return;
    }
    const userObj = {
      username: user.username,
      password: user.password,
    };
    const schema = Joi.object({
      username: Joi.string().min(3).max(30)
        .required(),
      password: Joi.string().min(6).max(30)
        .required(),
    });
    const res = Joi.validate(userObj, schema);
    let message = '';
    if (res.error === null) {
      await ctx.service.user.addUser(user);
      message = '<script language=javascript>alert("注册成功!!!");window.window.location.href="/";</script>';
    } else {
      message = '<script language=javascript>alert("注册失败!!请检查输入的数据是否正确");window.window.location.href="/register/view";</script>';
    }
    ctx.body = message;
  }

}

module.exports = AuthController;
